##Projeto Produtor/Consumidor

Este projeto implementa o problema clássico de Produtor/Consumidor usando semáforos e mutexes, garantindo a sincronização entre as tarefas produtoras e consumidoras. O código está dividido em arquivos .h e .c para melhorar a organização, legibilidade e facilidade de manutenção.
### Estrutura dos Componentes

   #### sem_mutex: Implementa o semáforo binário (mutex) usado para garantir exclusão mútua nas operações de acesso ao buffer compartilhado.

   ####sem: Implementa os semáforos responsáveis por gerenciar a disponibilidade de itens no buffer e controlar a sincronização entre o produtor e o consumidor. O semáforo buffer_full impede que o consumidor tente consumir quando o buffer está vazio, e o semáforo buffer_empty impede que o produtor insira novos itens quando o buffer está cheio.

    #### func: Contém as funções principais que implementam as tarefas de produção e consumo, além de outras utilitárias, como a função de Fibonacci para gerar itens de teste.

### Principais Funções

    uint8_t fibonacci(uint8_t in): Função responsável por gerar os itens a serem inseridos no buffer. Ela usa a sequência de Fibonacci para simular os dados produzidos.

    void init_semaphores_and_mutexes(void): Função que inicializa os semáforos buffer_empty e buffer_full, além do mutex. O semáforo buffer_empty é inicializado com o valor do tamanho total do buffer, e será decrementado à medida que itens forem inseridos. O buffer_full começa com zero e é incrementado conforme o produtor adiciona itens ao buffer.

### Como Funciona

    O produtor gera itens utilizando a sequência de Fibonacci e os insere no buffer compartilhado, respeitando o semáforo buffer_empty (espaço disponível no buffer).
    O consumidor retira itens do buffer, respeitando o semáforo buffer_full (quantidade de itens no buffer).
    Os semáforos garantem que o produtor só adicionará novos itens se houver espaço, e que o consumidor só retirará itens se houver algo no buffer.
    O mutex (semáforo binário) garante que o acesso ao buffer seja feito de forma segura, evitando condições de corrida.