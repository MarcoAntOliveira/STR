#ifndef FUNC_H
#define FUNC_H

#define BUFFER_SIZE 100
#define STACK_SIZE 100

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include "miros.h"
#include "func.h"
#include "sem.h"


uint8_t fibonacci(uint8_t in);
void init_semaphores_and_mutexes(sem_t *buffer_empty, sem_t *buffer_full,
sem_mutex_t *m);

// Função do produtor
void producer(sem_t *buffer_empty, sem_t *buffer_full,  sem_mutex_t *m);

// Função do consumidor
void consumer(sem_t *buffer_empty, sem_t *buffer_full,  sem_mutex_t *m) ;



#endif
