#include "func.h"
#include "miros.h"
#include <stdint.h>
#include "sem.h"
#include "sem_mutex.h"

#define BUFFER_SIZE 100
#define STACK_SIZE 100


OSThread producerThread;
OSThread consumerThread;

sem_t buffer_empty;  // Controla o espaço vazio no buffer
sem_t buffer_full;   // Controla os itens no buffer
sem_mutex_t m;  // Garante a exclusão mútua

unsigned int stack_producer[STACK_SIZE];
unsigned int stack_consumer[STACK_SIZE];


uint32_t stack_idleThread[40];
int main() {
	 // Inicialização do sistema operacional
	    OS_init(stack_idleThread, sizeof(stack_idleThread));

	    // Inicializa os semáforos e mutexes
	    init_semaphores_and_mutexes(&buffer_empty, &buffer_full, &m);

	    // Inicializa e inicia a thread do produtor
	       OSThread_start(&producerThread,
	                      2U, /* prioridade */
	                      producer,  // Passa a função do produtor
	                      stack_producer, sizeof(stack_producer));

	       // Inicializa e inicia a thread do consumidor
	       OSThread_start(&consumerThread,
	                      1U, /* prioridade */
	                      consumer,  // Passa a função do consumidor
	                      stack_consumer, sizeof(stack_consumer));

	    // Transfere controle para o RTOS
	    OS_run();
    return 0;
}
