
#include "func.h"
#include "sem.h"
#include "sem_mutex.h"


uint8_t in = 0;
uint8_t out = 0;
uint8_t buffer[BUFFER_SIZE];



extern OSThread producerThread;
extern OSThread consumerThread;
extern unsigned int stack_producer[STACK_SIZE];
extern unsigned int stack_consumer[STACK_SIZE];


uint8_t item;

uint8_t fibonacci(uint8_t in){
	uint8_t a1 = 0, a2 = 1, an;
	if(in == 0  || in == 1 ){
		return 1;
	}
	for(uint8_t i = 0; i < in; i++){

		an = a1 + a2;
		a1 = a2;
		a2 = an;
	}

	return an;

}
void init_semaphores_and_mutexes(sem_t *buffer_empty, sem_t *buffer_full,
sem_mutex_t *m){
    // Inicializa o semáforo do buffer
    buffer_empty->count = BUFFER_SIZE;  // Espaço vazio igual ao tamanho total do buffer
    buffer_empty->full = 0;             // Nenhum item no buffer no início
    buffer_empty->empty = BUFFER_SIZE;  // Buffer está completamente vazio

    buffer_full->count = 0;             // Nenhum item no buffer no início
    buffer_full->full = 0;              // Nenhum item completo
    buffer_full->empty = BUFFER_SIZE;   // Espaço máximo disponível

    // Inicializa o mutex
    m->value = 1;  // Mutex começa desbloqueado (disponível para uso)
}

// Função do produtor
void producer(sem_t *buffer_empty, sem_t *buffer_full,  sem_mutex_t *m) {

    uint8_t item;

    while(1){
    	sem_wait(buffer_empty, m);  // Espera por espaço disponível no buffer
		mutex_enter_critical(m);

		item = fibonacci(in);
		buffer[in] = item;
		in = (in + 1) % BUFFER_SIZE;

		mutex_exit_critical(m);
		sem_signal(buffer_full, m);  // Sinaliza que há um novo item no buffer


		OS_delay(TICKS_PER_SEC / 2);  // Simula tempo de produção
    }
}

// Função do consumidor
void consumer(sem_t *buffer_empty, sem_t *buffer_full,  sem_mutex_t *m) {
		uint8_t item;
    	while(1){
    	// Espera por um item disponível no buffer
    	sem_wait(buffer_full, m);
		mutex_enter_critical(m);

		item = buffer[out];
		out = (out + 1) % BUFFER_SIZE;

		mutex_exit_critical(m);
		sem_signal(buffer_empty, m);  // Sinaliza que há espaço disponível no buffer

        OS_delay(TICKS_PER_SEC);  // Simula tempo de consumo
        }
}


