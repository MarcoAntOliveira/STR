#include "jantar.h"

int main() {
    int Num_filosofos = 5;

    Jantar jantar(Num_filosofos);
    jantar.iniciar_jantar();

    return 0;
}
